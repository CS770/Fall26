CS 770 practice set: creative professionals on working with AI (10 interviews)

Source: Anthropic (2025), "Introducing Anthropic Interviewer: What 1,250 professionals told us about working with AI." https://www.anthropic.com/research/anthropic-interviewer
Data: https://huggingface.co/datasets/Anthropic/AnthropicInterviewer (creatives_transcripts.csv). Released under CC-BY; all participants consented to public release of their transcripts.

What is here: 10 of the 125 creatives transcripts (IDs 0001, 0003, 0011, 0012, 0026, 0029, 0044, 0053, 0054, 0077), unchanged, chosen for a mix of creative fields. Each is a 10 to 15 minute text interview. "User" is the participant. "AI" and "Assistant" are the interviewer, which was Claude following a rubric written by researchers.

Please do not try to work out who any participant is. A 2026 study showed that some interviewees in this dataset can be re-identified, so treat the text as you would any participant data.

For the assignment: name the analytic question you coded toward, and compare your themes with the ones Anthropic reports.
