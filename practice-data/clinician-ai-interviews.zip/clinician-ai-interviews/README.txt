CS 770 practice set: cancer-care staff on AI in their work (6 interviews)

Source: Bearup, L. (2026). "Artificial Intelligence in Digital Health: Understanding the perspectives of healthcare staff working to treat cancer." Harvard Dataverse. https://doi.org/10.7910/DVN/YSMLKW (CC0 1.0).

What is here: 6 of the 21 transcripts, unchanged, chosen for a mix of roles: Amanda (nurse), Duncan (clinician researcher), Beth (director/manager), Mari (pharmacist), Lilly (allied health, clinical informatics), Martin (data science). Interviews were conducted over Teams in 2025 by a human interviewer (Luke), at a specialist cancer centre in Victoria, Australia, with university and hospital ethics approval. Participants consented to the research use of de-identified transcripts; names are pseudonyms and identifying details are redacted (XXX).

The interview covers: (1) the main challenges in diagnosing and treating cancer, (2) thoughts on AI, (3) any directives or documentation received on appropriate AI use, (4) anything else. The full set of 21 is at the DOI above if you want more.

Please do not try to work out who any participant is or where they work.
